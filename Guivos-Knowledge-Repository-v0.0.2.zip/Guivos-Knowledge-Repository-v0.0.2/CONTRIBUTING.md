# Contributing

## Regra principal

Toda alteração deve preservar a coerência com o Guivos Ecosystem Blueprint (GEB).

## Fluxo recomendado

1. Criar ou editar arquivos Markdown.
2. Registrar decisões relevantes em ADR.
3. Atualizar links internos quando necessário.
4. Registrar mudanças no `CHANGELOG.md`.
5. Fazer commit com mensagem objetiva.

## Padrão de commit sugerido

- `docs: add foundation section`
- `adr: add decision about opportunities`
- `refactor: reorganize ecosystem structure`
