# ADR-001 — GKR como base de conhecimento versionada

## Status

Aprovada

## Decisão

A Guivos utilizará o Guivos Knowledge Repository (GKR) como base oficial de conhecimento, em Markdown e versionada por Git.

## Justificativa

O conhecimento validado da Guivos não deve depender de conversas ou documentos isolados.

## Consequências

Toda decisão aprovada deverá ser incorporada ao GKR.
