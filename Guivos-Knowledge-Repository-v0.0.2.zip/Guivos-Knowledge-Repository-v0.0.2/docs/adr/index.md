# Architecture Decision Records (ADR)

Esta pasta registra decisões arquiteturais relevantes da Guivos.

## ADRs

- [ADR-001 — GKR como base de conhecimento versionada](ADR-001-gkr-as-knowledge-base.md)
- [ADR-002 — Fundação da Guivos](ADR-002-foundation-principles.md)
