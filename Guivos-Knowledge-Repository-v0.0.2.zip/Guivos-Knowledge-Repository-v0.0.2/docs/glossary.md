# Glossário Oficial

## Participante

Entidade capaz de interagir com o ecossistema Guivos. Pode ser Pessoa, Organização ou Coletivo.

## Pessoa

Participante individual, autônomo, capaz de viver jornadas de evolução.

## Organização

Participante institucional capaz de gerar, apoiar ou sustentar oportunidades.

## Coletivo

Agrupamento organizado em torno de propósito, interesse, causa ou objetivo comum.

## Oportunidade

Iniciativa estruturada que permite a um participante avançar em sua jornada por meio de uma experiência.

## Experiência

Materialização da participação de um ou mais participantes em uma oportunidade.

## Próximo Passo

Hipótese de evolução mais relevante para o momento atual do participante.

## Conhecimento do Ecossistema

Conjunto organizado de padrões, aprendizados e evidências produzidos pelas experiências vividas no ecossistema.
