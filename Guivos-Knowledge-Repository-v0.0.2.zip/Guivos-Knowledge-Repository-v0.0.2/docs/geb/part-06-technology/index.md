# part-06-technology

Estrutura reservada para desenvolvimento futuro.
