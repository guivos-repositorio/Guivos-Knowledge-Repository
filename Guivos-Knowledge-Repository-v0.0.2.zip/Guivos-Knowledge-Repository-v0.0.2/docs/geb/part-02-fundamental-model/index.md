# Parte II — Modelo Fundamental

Esta parte define o núcleo arquitetural da Guivos.

## Modelo

Participante → Momento Atual → Objetivos → Próximo Passo → Oportunidades → Experiências → Relacionamentos → Evidências de Evolução → Novo Momento de Vida
