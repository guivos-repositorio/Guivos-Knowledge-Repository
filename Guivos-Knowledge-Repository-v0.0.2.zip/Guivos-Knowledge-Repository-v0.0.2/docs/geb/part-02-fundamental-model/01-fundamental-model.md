# Modelo Fundamental da Guivos

O modelo fundamental representa como a Guivos entende a evolução de um participante.

```mermaid
flowchart TD
    A[Participante] --> B[Momento Atual]
    B --> C[Objetivos]
    C --> D[Próximo Passo]
    D --> E[Oportunidades]
    E --> F[Experiências]
    F --> G[Relacionamentos]
    G --> H[Evidências de Evolução]
    H --> I[Novo Momento de Vida]
```
