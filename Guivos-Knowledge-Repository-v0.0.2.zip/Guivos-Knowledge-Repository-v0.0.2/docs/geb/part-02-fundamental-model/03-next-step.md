# Próximo Passo

O Próximo Passo representa a hipótese de evolução mais relevante para o contexto atual do participante.

Ele não é uma oportunidade. Ele orienta quais oportunidades devem ser recomendadas.
