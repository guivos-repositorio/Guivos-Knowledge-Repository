# Modelo da Jornada

A jornada representa a sequência contínua de estados vividos por um participante.

A Guivos não conduz a jornada. A plataforma apoia a decisão do participante por meio de contexto, recomendações, conexões e oportunidades.
