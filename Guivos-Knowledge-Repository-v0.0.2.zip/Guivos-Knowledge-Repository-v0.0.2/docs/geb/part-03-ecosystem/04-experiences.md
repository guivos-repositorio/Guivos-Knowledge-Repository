# Modelo das Experiências

Experiência é a materialização da participação de um ou mais participantes em uma oportunidade.

A oportunidade possui potencial de transformação. A experiência realiza essa transformação.
