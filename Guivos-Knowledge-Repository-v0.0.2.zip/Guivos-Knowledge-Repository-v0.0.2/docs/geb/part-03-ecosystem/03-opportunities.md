# Modelo das Oportunidades

Oportunidade é uma iniciativa estruturada que permite a um ou mais participantes avançarem em suas jornadas por meio de uma experiência.

## Ciclo de vida

Concepção → Planejamento → Publicação → Descoberta → Participação → Experiência → Encerramento → Legado
