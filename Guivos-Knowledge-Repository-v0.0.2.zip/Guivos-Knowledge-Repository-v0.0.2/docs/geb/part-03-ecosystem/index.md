# Parte III — Arquitetura do Ecossistema

Esta parte descreve como o ecossistema funciona.

## Componentes

- Funcionamento do Ecossistema
- Modelo dos Participantes
- Modelo das Oportunidades
- Modelo das Experiências
- Modelo do Conhecimento do Ecossistema
