# Pessoa

Pessoa é um participante individual capaz de definir objetivos, viver experiências, estabelecer relacionamentos e evoluir continuamente ao longo de sua jornada.
