# Modelo dos Participantes

Participantes são entidades capazes de interagir com o ecossistema Guivos.

Categorias:

- Pessoa
- Organização
- Coletivo
