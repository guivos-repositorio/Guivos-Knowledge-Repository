# Capacidades

Capacidades representam aquilo que um participante pode realizar para contribuir com o ecossistema.

Exemplos:

- Descobrir
- Criar
- Participar
- Conectar
- Organizar
- Compartilhar
- Apoiar
- Representar
- Administrar
