# Coletivo

Coletivo é um agrupamento organizado em torno de propósito, interesse, causa ou objetivo comum.

Na interface, pode aparecer como movimento, grupo, clube, comunidade, rede ou núcleo.
