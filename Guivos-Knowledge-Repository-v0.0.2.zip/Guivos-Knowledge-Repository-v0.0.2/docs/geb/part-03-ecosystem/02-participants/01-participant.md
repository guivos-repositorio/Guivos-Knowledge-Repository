# Participante

Um participante é qualquer entidade capaz de interagir com o ecossistema Guivos de maneira ativa ou passiva, contribuindo para jornadas de evolução.
