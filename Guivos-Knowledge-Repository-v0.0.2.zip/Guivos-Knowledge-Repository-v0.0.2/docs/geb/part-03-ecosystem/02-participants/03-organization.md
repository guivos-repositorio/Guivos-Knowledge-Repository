# Organização

Organização é um participante institucional capaz de gerar, apoiar ou sustentar oportunidades dentro do ecossistema.
