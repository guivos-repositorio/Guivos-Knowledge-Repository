# Relacionamentos

Relacionamentos são vínculos reconhecidos entre participantes, formados por experiências, interações ou objetivos compartilhados.

Eles representam patrimônio relacional do ecossistema.
