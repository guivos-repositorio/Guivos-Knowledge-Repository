# Funcionamento do Ecossistema

O ecossistema Guivos gera valor por meio do ciclo:

```mermaid
flowchart TD
    A[Participantes] --> B[Jornadas]
    B --> C[Próximos Passos]
    C --> D[Oportunidades]
    D --> E[Experiências]
    E --> F[Relacionamentos]
    F --> G[Conhecimento]
    G --> H[Novos Próximos Passos]
```

A IA interpreta o conhecimento do ecossistema. Ela não define a arquitetura.
