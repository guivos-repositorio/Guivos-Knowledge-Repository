# Guivos Knowledge Repository

O GKR é a fonte oficial de conhecimento da Guivos.

Ele existe para preservar, organizar e versionar a arquitetura corporativa, os princípios, decisões e especificações da plataforma.

## Conteúdo

- Guivos Ecosystem Blueprint (GEB)
- ADRs
- Glossário
- Diagramas
- Roadmap documental
