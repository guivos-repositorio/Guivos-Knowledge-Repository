# License

Copyright Guivos.

Uso interno e estratégico. A licença definitiva deverá ser definida pela Guivos antes de publicação pública.
