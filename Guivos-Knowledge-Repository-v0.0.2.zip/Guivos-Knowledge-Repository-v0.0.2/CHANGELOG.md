# Changelog

## 0.0.2 — Consolidação da Parte I — Fundação

- Consolidação dos arquivos principais da Parte I do GEB.
- Inclusão de essência, propósito, missão operacional, visão de longo prazo, constituição e princípios permanentes.
- Padronização inicial com frontmatter YAML nos arquivos da Fundação.
- Atualização do índice da Parte I.
- Inclusão de ADR sobre a Fundação da Guivos.

## 0.0.1 — Estrutura inicial

- Criação da estrutura base do Guivos Knowledge Repository.
- Inclusão da estrutura inicial do Guivos Ecosystem Blueprint.
- Inclusão de pastas para ADRs, diagramas, assets e exports.
