# Guivos Knowledge Repository (GKR)

Repositório oficial de conhecimento da Guivos.

Este repositório centraliza a arquitetura, decisões, documentação estratégica, modelos, diagramas e especificações da Guivos em Markdown, com versionamento em Git.

## Artefatos principais

- `docs/geb/` — Guivos Ecosystem Blueprint
- `docs/adr/` — Architecture Decision Records
- `docs/glossary.md` — Glossário oficial
- `docs/diagrams/` — Diagramas em Mermaid ou imagens
- `exports/` — Exportações PDF/DOCX

## Princípio

Nenhum conhecimento validado da Guivos deve existir apenas em conversas.  
Toda decisão aprovada deve ser incorporada ao GKR.
