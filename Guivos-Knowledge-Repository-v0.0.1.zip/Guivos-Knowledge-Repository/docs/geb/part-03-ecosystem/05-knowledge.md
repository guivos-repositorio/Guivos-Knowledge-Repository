# Modelo do Conhecimento do Ecossistema

Conhecimento do Ecossistema é o conjunto organizado de padrões, aprendizados e evidências produzidos continuamente pelas experiências vividas pelos participantes.

Dados representam registros.  
Conhecimento representa compreensão.  
Inteligência Artificial representa interpretação aplicada.
