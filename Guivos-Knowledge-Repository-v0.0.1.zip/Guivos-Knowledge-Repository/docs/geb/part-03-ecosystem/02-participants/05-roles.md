# Papéis

Papéis representam a forma como um participante atua em determinado contexto.

Identidade responde: quem é o participante.  
Papel responde: como ele está atuando neste momento.
