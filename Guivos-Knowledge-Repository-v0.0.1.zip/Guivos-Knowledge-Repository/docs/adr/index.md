# Architecture Decision Records (ADR)

Esta pasta registra decisões arquiteturais relevantes da Guivos.
