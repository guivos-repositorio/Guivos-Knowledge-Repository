# Changelog

## 0.0.1 — Estrutura inicial

- Criação da estrutura base do Guivos Knowledge Repository.
- Inclusão da estrutura inicial do Guivos Ecosystem Blueprint.
- Inclusão de pastas para ADRs, diagramas, assets e exports.
